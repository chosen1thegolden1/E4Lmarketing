E4L MARKETING SITE - HANDOFF FOR ABDULLAH

Read in this order:
  1-START-HERE.md          one page, the whole job in order (also as .html)
  2-FULL-DEPLOY-GUIDE.md   every URL, setting, and test (also as .html)

Folders:
  pages-to-paste/      the eight finished pages. One Custom Code element per
                       GHL funnel step, paste the ENTIRE file.
  images-to-upload/    upload every file to Media Storage > CS-site.
                       Keep the file names exactly as they are.
  source/              the templates and build.py. Only needed if you edit
                       copy or change config and rebuild (python3 build.py).
  malik-chat-agent/    Malik's persona and how he is wired (reference only;
                       the agent already exists in ElevenLabs).

Before you paste the pages, do the config step in the guide: the pages need
the Media Library image base URL and the two webhook URLs. Without Python,
open each page file, find the line starting with  window.E4L_CONFIG=  and
edit the values by hand, then find-and-replace
  https://chosen1thegolden1.github.io/E4Lmarketing/assets/
with your Media Library base URL (ending in a slash).

Everything goes in the E4L Services sub-account. Never the school.
Every GHL asset starts with CS-.
Questions: chosen1@gsgagency.com
